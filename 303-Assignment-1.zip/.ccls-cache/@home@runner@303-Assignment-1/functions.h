#include <iostream>
using namespace std;

void findIndex(int array[], int size);
//Function to find the index in the array and let the user know
void modArray(int array[], int size);
//Function to get a number and index from the user and change the current index in the array with that number
void addendArray(int array[], int size);
//Function to add a given number to the end of an array
void removeIndxArray(int array[], int size);
//Function to remove an index from the array